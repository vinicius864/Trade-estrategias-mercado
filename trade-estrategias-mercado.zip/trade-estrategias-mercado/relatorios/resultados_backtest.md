# Resultados dos Backtests

Aqui você pode documentar os resultados das estratégias testadas.
