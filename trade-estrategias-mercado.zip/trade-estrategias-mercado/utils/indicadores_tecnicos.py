# Aqui você pode adicionar funções para calcular indicadores como RSI, Médias Móveis, etc.
