# Estratégias de Trade no Mercado Financeiro

Este repositório contém scripts e notebooks com estratégias de trading utilizando análise técnica. Ideal para estudos e testes com dados históricos de ações, criptomoedas e outros ativos.

## Conteúdo

- Estratégias com indicadores técnicos (RSI, Médias Móveis, Suporte/Resistência)
- Ferramentas para backtest
- Análise e visualização de resultados

## Requisitos

Instale as dependências com:

```
pip install -r requirements.txt
```

## Licença

MIT
